export class Challenge {
    public fromId: string;
    public toId: String;
}
