while true
do
python sendNotif.py
sleep 21600s
done

